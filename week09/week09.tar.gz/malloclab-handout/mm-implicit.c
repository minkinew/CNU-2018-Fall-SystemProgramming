/*
 * mm-implicit.c - an empty malloc package
 *
 * NOTE TO STUDENTS: Replace this header comment with your own header
 * comment that gives a high level description of your solution.
 *
 * @id : 201502023
 * @name : 김민기
 */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "mm.h"
#include "memlib.h"

/* If you want debugging output, use the following macro.  When you hand
 * in, remove the #define DEBUG line. */
#define DEBUG
#ifdef DEBUG
# define dbg_printf(...) printf(__VA_ARGS__)
#else
# define dbg_printf(...)
#endif


/* do not change the following! */
#ifdef DRIVER
/* create aliases for driver tests */
#define malloc mm_malloc
#define free mm_free
#define realloc mm_realloc
#define calloc mm_calloc
#endif /* def DRIVER */

/* single word (4) or double word (8) alignment */
#define ALIGNMENT 8

/* rounds up to the nearest multiple of ALIGNMENT */
#define ALIGN(p) (((size_t)(p) + (ALIGNMENT-1)) & ~0x7)
#define SIZE_T_SIZE (ALIGN(sizeof(size_t)))
#define SIZE_PTR(p) ((size_t*)(((char*)) - SIZE_T_SIZE))

//word 크기 결정
#define WSIZE 4 
//double word 크기 결정
#define DSIZE 8 
//초기 heap 크기를 결정
#define CHUNKSIZE (1<<12) 
// header + footer의 크기 
#define OVERHEAD 8 
//x와 y 값 중에서 더 큰값
#define MAX(x, y) ((x) > (y) ? (x) : (y))
//PACK매크로를 사용하여 size와 alloc의 값을 하나의 word로 묶음
#define PACK(size, alloc) ((size) | (alloc))
//포인터 p가 가리키는 위치에서 word크기의 값을 잃는다
#define GET(p) (*(unsigned int*)(p))
//포인터 p가 가리키는 곳에 word크기의 val 값을 쓴다
#define PUT(p, val) (*(unsigned int*)(p) = (val))
//포인터 p가 가리키는 곳에서 한 word를 읽은 다음 하위3bit를 버림 
#define GET_SIZE(p) (GET(p) & ~0x7)
//포인터 p가 가리키는 곳에서 한 word를 읽은 다음 하위 1bit를 읽음
#define GET_ALLOC(p) (GET(p) & 0x1)
//주어진 포인터 bp의 header의 주소를 계산
#define HDRP(bp) ((char*)(bp) - WSIZE)
//주어진 포인터 bp의 footer의 주소를 계산
#define FTRP(bp) ((char*)(bp) + GET_SIZE(HDRP(bp)) - DSIZE)
//주어진 포인터 bp를 이용하여 다음 block의 주소를 계산
#define NEXT_BLKP(bp) ((char*)(bp)  + GET_SIZE(((char*)(bp) - WSIZE)))
//주어진 포인터 bp를 이용하여 이전 block의 주소를 계산
#define PREV_BLKP(bp) ((char*)(bp)  - GET_SIZE(((char*)(bp) - DSIZE)))

int mm_init(void);
void *malloc (size_t size);
void free (void *bp);
void *realloc(void *oldptr, size_t size);
static void *extend_heap(size_t words);
static void *coalesce(void *bp);
void *calloc (size_t nmemb, size_t size);
void mm_checkheap(int verbose);
static void place(void *bp, size_t asize);
static void *find_fit(size_t asize);

static char *heap_listp=0 ;
static char *nextfit ;


/*
 * Initialize: return -1 on error, 0 on success.
 */
int mm_init(void) { //heap을 초기화하는 함수
	//초기 empty heap 생성
	//heap_list = 새로 생성되는 heap영역의 시작 주소
	if((heap_listp = mem_sbrk(4*WSIZE)) == NULL)
		return -1;
	
	PUT(heap_listp, 0); //정렬을 위한 의미없는 값
	PUT(heap_listp + WSIZE, PACK(OVERHEAD, 1) ); //prologue header
	PUT(heap_listp + DSIZE, PACK(OVERHEAD, 1) ); //prologue footer
	PUT(heap_listp + WSIZE + DSIZE, PACK(0, 1) ); //epilogue header
	heap_listp += DSIZE;

	//CHUNKSIZE 바이트의 free block 만큼 empty heap을 확장
	//생성된 empty heap을 free block으로 확장	
	//WSIZE로 align 되어있지 않으면 에러

	/* 불필요한 공간이 생성되므로 주석처리
	if (extend_heap(CHUNKSIZE/WSIZE) == NULL)
		return -1; 
	*/

	// 새로 생성되는 heap의 시작주소 저장(next fit방식)	
	nextfit = heap_listp; 
    return 0;
}
/*
 * malloc
 */
void *malloc (size_t size) { //size크기의 블록을 heap에 할당하는 함수
	size_t asize;
	size_t extendsize;
	char *bp;
	
	//size가 0이면 할당할 필요가 없으므로 null을 리턴
	if(size == 0)
		return NULL;

	//할당하려는 사이즈가 8보다 작거나 같은 경우 
	//asize = DSIZE + OVERHEAD(header, footer)
	if(size <= DSIZE)
		asize = DSIZE + OVERHEAD;                            
	
	//할당하려는 사이즈가 8보다 클 경우 
	//8byte 단위블록으로 할당하기 위한 size로 블록을 할당
	else
		//8의 배수중 가장 근접한 숫자만큼 할당
		asize = DSIZE * ((size + OVERHEAD + (DSIZE-1)) / DSIZE);

	//할당하려는 size와 맞는 free블록이 있으면 할당
	if((bp = find_fit(asize)) != NULL){ 
		place(bp, asize); 
		return bp;
	}
	
	//asize와 CHUNKSIZE 중 큰 값으로 확장
	extendsize = MAX(asize, CHUNKSIZE);
	
	//extendsize 만큼 확장
	if((bp = extend_heap(extendsize/WSIZE)) == NULL )
		return NULL;                              
        
	place(bp, asize);
	return bp;
}

/*
 * coalesce
 */
static void *coalesce(void *bp) { //인접한 free상태의 블록을 합쳐주는 함수
	//이전 블록의 할당 여부 0 = No, 1 = Yes
	size_t prev_alloc = GET_ALLOC(FTRP(PREV_BLKP(bp)));
	//다음 블록의 할당 여부 0 = No, 1 = Yes
	size_t next_alloc = GET_ALLOC(HDRP(NEXT_BLKP(bp)));
	//현재 블럭의 크기
	size_t size = GET_SIZE(HDRP(bp));

	//case1 : 이전 블록, 다음블록 최하위 bit가 둘다 1인 경우 (할당) 	
	if(prev_alloc && next_alloc){
		//모두 할당되어 있으므로 bp 리턴
		return bp;
	}

	//case2 : 이전블록 최하위 bit가 1, 다음 블록 최하위 bit가 0인 경우 (비할당) 다음 블록과 병합한 뒤 bp return           
	else if(prev_alloc && !next_alloc){
		//이전 블록만 할당되어 있으므로 현재 size에 다음 블록 size 더함
		size += GET_SIZE(HDRP(NEXT_BLKP(bp)));
		//bp의 header에 블록 size와 alloc = 0을 저장
		PUT(HDRP(bp), PACK(size, 0));
		//bp의 footer에 블록 size와 alloc = 0을 저장
		PUT(FTRP(bp), PACK(size, 0));
	}
	
	//case3 : 이전블록 최하위 bit가 0이고 (비할당), 다음 블록 최하위 bit가 1인 경우(할당) 이전 블록과 병합한 뒤 새로운 bp return
	else if(!prev_alloc && next_alloc){
		//다음 블록만 할당되어 있으므로 현재 size에 이전 블록 size 더함
		size += GET_SIZE(HDRP(PREV_BLKP(bp)));
		//bp의 footer에 블록 size와 alloc = 0을 저장
		PUT(FTRP(bp), PACK(size, 0));  
		//bp의 header에 블록 size의 alloc = 0을 저장
		PUT(HDRP(PREV_BLKP(bp)), PACK(size, 0));
		//이전 블록의 포인터를 저장
		bp = PREV_BLKP(bp);
	}

	//case4 : 이전블록 최하위 bir가 0이고 (비할당), 다음 블록 최하위 bir가 0인 경우(비할당) 이전블록, 현재블록, 다음블록을 모두 병합한 뒤 새로운 bp return
	else {
		//현재블록, 이전블록, 다음블록의 size를 더함
		size += GET_SIZE(HDRP(PREV_BLKP(bp))) +  GET_SIZE(FTRP(NEXT_BLKP(bp)) );
		//이전 블록 bp의 header에 더해진 size와 alloc = 0을 저장
		PUT(HDRP(PREV_BLKP(bp)), PACK(size, 0));
		//다음 블록 bp의 footer에 더해진 size와 alloc = 0을 저장
		PUT(FTRP(NEXT_BLKP(bp)), PACK(size, 0));
		//이전 블록의 포인터를 저장
		bp = PREV_BLKP(bp);
	}
	nextfit = bp;
	//병합된 블록의 주소 bp return
	return bp;
}
/*
 *place
 */
static void place(void *bp, size_t asize) { //bp 위치에 asize 크기의 메모리를 위치시키는 함수

	//bp가 가리키는 header에서 size를 가져와서 저장
	size_t newsize = GET_SIZE(HDRP(bp)); 

	//header에서 가져온 size와 할당하려는 size의 차가
	//블록의 최소크기인 16보다 크거나 같을 떄
	//블록을 분할
	if((newsize - asize) >= (2*DSIZE)){
		//header에 asize와 1을 or연산 한 것을 넣음
		PUT(HDRP(bp), PACK(asize, 1));  
		//footer에 asize와 1을 or연산 한 것을 넣음
		PUT(FTRP(bp), PACK(asize, 1));  
		//다음블록으로 이동
		bp = NEXT_BLKP(bp);
		//header에 newsize-asize한 size를 넣고 비할당상태로 만듬 
		PUT(HDRP(bp), PACK(newsize-asize, 0)); 
		//footer에 newsize-asize를 size를 넣고 비할당상태로 만듬
		PUT(FTRP(bp), PACK(newsize-asize, 0)); 
	}
	//블록의 최소크기보다 작을 떄
	//블록을 분할하지 않음
	else{ 
		PUT(HDRP(bp), PACK(newsize, 1)); 
		PUT(FTRP(bp), PACK(newsize, 1));
	}
}
/*
 *extend_heap
 */
static void *extend_heap(size_t words) { //요청 받은 크기의 빈 블록을 만들어줌. 이전 블록을 검사하여 case별로 free시켜주도록 구현하는 함수

	char *bp;
	size_t size;
	//word가 짝수이면 word*WSIZE, 홀수이면 짝수로 만들어 준 뒤 WSIZE를 곱함
	size = (words % 2) ? (words + 1) * WSIZE : words * WSIZE; 
 	
	//mem_sbrk를 통해 size만큼 heap을 확장
	if((long)(bp = mem_sbrk(size)) == -1) 
		return NULL;

	//확장한블록의 header에 size를 넣고 free블록표시
	PUT(HDRP(bp), PACK(size, 0)); 
	//확장한블록의 footer에 size를 넣고 free블록표시
	PUT(FTRP(bp), PACK(size, 0)); 
	//확장했으므로 epilogue를 표시하고
	//다음 블록의 header에 alloc부분을 1로 만들어줌.
	PUT(HDRP(NEXT_BLKP(bp)), PACK(0,1)); 
                                             
	//coalesce를 이용해 free블록끼리 결합
	return coalesce(bp);
}
/*
 *find_fit
 */
static void *find_fit(size_t asize) { //free block을 검색하는 함수
	//nextfit으로 구현

	void *bp;
	//초기값을 nextfit으로 설정해서 검색이 끝난위치부터 다시 검색을 하도록함
	for(bp = nextfit; GET_SIZE(HDRP(bp)) > 0; bp = NEXT_BLKP(bp)){  
		if(!GET_ALLOC(HDRP(bp)) && (asize <= GET_SIZE(HDRP(bp)))){
			return  bp;
		}
	} 
	
	return NULL;
	
}

/*
 * free
 */
void free (void *bp){
	//잘못된 free요청일 경우 함수종료
	if (bp == 0) 
		return;

	//bp의 header에서 block size를 읽어옴.
	size_t size = GET_SIZE(HDRP(bp)); 

	//bp의 header에 블록 size와 alloc=0을 저장
	PUT(HDRP(bp), PACK(size, 0));	
	//bp의 footer에 블록  size와 alloc=0을 저장
	PUT(FTRP(bp), PACK(size, 0));
	//주위에 빈 블록이 있으면 병합
	nextfit = coalesce(bp);
}

/*
 * realloc - you may want to look at mm-naive.c
 */
void *realloc(void *oldptr, size_t size) {
	size_t oldsize;
	void *newptr;

	//size가 0이면 free시키고 null을 리턴
	if(size == 0) {
		free(oldptr);
		return 0;
	}

	// oldptr이 null이면, 새로 할당
	if(oldptr == NULL) 
		return malloc(size);
	
	//새로운 공간 할당
	newptr = malloc(size);

	//realloc()이 실패할 경우 원래 블록은 그대로
	if(!newptr) 
		return 0;
	
	//이전 데이터를 복사
	oldsize = GET_SIZE(HDRP(oldptr));

	if(size < oldsize) 
		oldsize = size;

	memcpy(newptr, oldptr, oldsize);

	//이전 공간 free
	free(oldptr);

	return newptr;
}
/*
 * calloc - you may want to look at mm-naive.c
 * This function is not tested by mdriver, but it is
 * needed to run the traces.
 */
void *calloc (size_t nmemb, size_t size) {
   return NULL;
}


/*
 * Return whether the pointer is in the heap.
 * May be useful for debugging.
 */
static int in_heap(const void *p) {
    return p < mem_heap_hi() && p >= mem_heap_lo();
}

/*
 * Return whether the pointer is aligned.
 * May be useful for debugging.
 */
static int aligned(const void *p) {
    return (size_t)ALIGN(p) == (size_t)p;
}

/*
 * mm_checkheap
 */
void mm_checkheap(int verbose) {
}
